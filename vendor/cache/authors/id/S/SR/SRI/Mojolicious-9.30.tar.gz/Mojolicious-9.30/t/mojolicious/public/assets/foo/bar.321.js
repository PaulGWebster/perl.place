/*
 * foo/bar.js asset
 */
