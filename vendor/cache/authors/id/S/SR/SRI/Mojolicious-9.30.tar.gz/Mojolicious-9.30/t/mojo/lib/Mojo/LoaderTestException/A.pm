package Mojo::LoaderException::A;
use Mojo::Base -base;

sub new { }

foo {

1;
