package Mojo::LoaderTest::E::F;
use Mojo::Base -base;

1;
